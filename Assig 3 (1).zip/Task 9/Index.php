<?php
include("header.php");





?>

<a href="http://localhost/Assignment%203%20Requests/Task%209/handle.php?msg=Hello%20World">Click Here</a>

