<?php
if(isset($_GET["msg"]));
    echo"the message is :" . htmlspecialchars($_GET["msg"]);
?>
